## Final Project Base Project

This repo contains a good starting place for getting a static website running on Heroku.

