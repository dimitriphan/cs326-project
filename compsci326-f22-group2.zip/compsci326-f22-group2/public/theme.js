
$(document).ready(function() {

    //set local storage metric variable to the selected metric
    if (!localStorage.getItem('metric')) {
        localStorage.setItem('metric', 'reviewcount');
    }
    if (localStorage.getItem('metric') == 'playercount') {
        $("#playerCount").prop("checked", true)
    }
    if (localStorage.getItem('metric') == 'reviewpercentage') {
        $("#reviewPercentage").prop("checked", true)
    }
    
    //---------------------------------------
    //checking theme
    if (!(localStorage.getItem('theme'))) {
        localStorage.setItem('theme', 'dark');
    }
    if (localStorage.getItem('theme') == 'dark') {
        $('#darkThemeBox').prop("checked", true)
        toggleDarkOn();
    }
    else{
        toggleDarkOff();
    }
})

$('#darkThemeBox').change(function() {
    if (this.checked) {
        localStorage.setItem('theme', 'dark');
        toggleDarkOn();
    }
    else {
        localStorage.setItem('theme', 'light');
        toggleDarkOff();
    }
});

function toggleDarkOn() {
    $(".lightTheme").removeClass("lightTheme").addClass("darkTheme");
    $('button.account.light').css("visibility", "hidden");
    $('button.account.dark').css("visibility", "visible");
}

function toggleDarkOff() {
    $('.darkTheme').removeClass("darkTheme").addClass("lightTheme");
    $('button.account.light').css("visibility", "visible");
    $('button.account.dark').css("visibility", "hidden");
}


$('.metricSet').change(function() {
    if ($("#reviews").is(':checked')) {
        localStorage.setItem('metric', 'reviewcount');
        // add view switch
    }
    if ($("#playerCount").is(':checked')) {
        localStorage.setItem('metric', 'playercount');
        // add view switch
    }
    if ($("#reviewPercentage").is(':checked')) {
        localStorage.setItem('metric', 'reviewpercentage');
        // add view switch
    }
});
