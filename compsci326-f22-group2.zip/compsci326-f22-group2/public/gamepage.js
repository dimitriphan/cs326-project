let games = [
    {
        "title": "Hollow Knight",
        "cover-art" : 'https://www.mobygames.com/images/covers/l/487280-hollow-knight-nintendo-switch-front-cover.jpg',
        "reviews" : 224573,
        "positiveRatingPercent" : 97
    },
    {
        "title": "Slay the Spire",
        "cover-art": "https://www.mobygames.com/images/covers/l/561995-slay-the-spire-playstation-4-front-cover.jpg",
        "reviews": 101085,
        "positiveRatingPercent": 97
    },
    {
        "title": "Elden Ring",
        "cover-art": "https://asset.vg247.com/elden-ring-cover-art.jpg/BROK/thumbnail/1200x1200/quality/100/elden-ring-cover-art.jpg",
        "reviews": 412489,
        "positiveRatingPercent": 90
    },
    {
        "title": "Grand Theft Auto V",
        "cover-art": "https://i.pinimg.com/originals/62/0c/89/620c89a5f0347147ea17036be706fc1b.png",
        "reviews": 1302554,
        "positiveRatingPercent": 85
    },
    {
        "title": "God of War",
        "cover-art": 'https://cdn.vox-cdn.com/thumbor/lZYVMlOfLbZsA6GqBPWmXpsdlPc=/1400x1400/filters:format(jpeg)/cdn.vox-cdn.com/uploads/chorus_asset/file/10692939/687474703a2f2f692e696d6775722e636f6d2f476c537665734d2e6a7067.jpg',
        "reviews": 43702,
        "positiveRatingPercent": 96
    },
    {
        "title": "Lost Ark",
        "cover-art": "https://www.gameinformer.com/sites/default/files/styles/product_box_art/public/2021/06/10/975b51a0/lostark.jpg",
        "reviews": 174364,
        "positiveRatingPercent": 73
    },
    {
        "title": "Warhammer",
        "cover-art": "https://cdna.artstation.com/p/assets/images/images/001/037/698/large/diego-gisbert-llorens-whq01cover-wip9e1.jpg?1443928033",
        "reviews": 67813,
        "positiveRatingPercent": 83
    },
    {
        "title": "Warframe",
        "cover-art": "https://warframe-school.com/wp-content/uploads/2018/07/Warframe-Logo.png",
        "reviews": 510740,
        "positiveRatingPercent": 87
    },
    {
        "title": "Deep Rock Galactic",
        "cover-art": "https://lh3.googleusercontent.com/c6IAxCs1Pb2BGfnAZwC1ip6LAD7wL7yJiV4tIhn8bnFAIpoqG-32uZ5ahaQzhASlRe5qTy24GMStOBYUFzXc4ImR",
        "reviews": 122842,
        "positiveRatingPercent": 97
    }
]

$('#higherButton').click(checkHigher);
$('#lowerButton').click(checkLower);

function checkHigher(){
    let $score = $('#score').text();
    let game1 = games.find(game => game.title === $('.title1').text());
    let game2 = games.find(game => game.title === $('.title2').text());

    if(game1.reviews <= game2.reviews){
        let newGameIndex = Math.floor(Math.random()*games.length);
        while(games[newGameIndex].title === game2.title){
            newGameIndex = Math.floor(Math.random()*games.length);
        }
        incrementScore();
        $('#img1').attr('src', $('#img2').attr('src'));
        $('#img2').attr('src', games[newGameIndex]["cover-art"]);
        updateInfo(game2, games[newGameIndex]);
    }else{
        alert("Nice try! You got " + $score + " correct! " + game2.title + " has " + game2.reviews + " reviews.");
        reset();
    }
}

function checkLower(){
    let $score = $('#score').text();
    let game1 = games.find(game => game.title === $('.title1').text());
    let game2 = games.find(game => game.title === $('.title2').text());
    if(game1.reviews >= game2.reviews){
        let newGameIndex = Math.floor(Math.random()*games.length);
        while(games[newGameIndex].title === game2.title){
            newGameIndex = Math.floor(Math.random()*games.length);
        }
        incrementScore();
        $('#img1').attr('src', $('#img2').attr('src'));
        $('#img2').attr('src', games[newGameIndex]["cover-art"]);
        updateInfo(game2, games[newGameIndex]);
    }else{
        alert("Nice try! You got " + $score + " correct! " + game2.title + " has " + game2.reviews + " reviews.");
        reset();
    }
}

function incrementScore(){
    let $score = $('#score').text();

    $score = parseInt($score);
    $score+=1;
    $('#score').html($score);
}

function reset(){
    let index1 = Math.floor(Math.random()*games.length);
    let index2 = Math.floor(Math.random()*games.length);
    while(index1===index2){
        index2 = Math.floor(Math.random()*games.length);
    }
    $('#score').html('0');
    $('#img1').attr('src', games[index1]["cover-art"]);
    $('#img2').attr('src', games[index2]["cover-art"]);
    $('.title1').html(games[index1].title);
    $('.title2').html(games[index2].title);
    $('.metric1').html(games[index1].reviews + ' reviews');
}

function updateInfo(g1, g2){
   $('.title1').html(g1.title);
   $('.title2').html(g2.title);
   $('.metric1').html(g1.reviews + ' reviews');
}

$(".settings").click(function () {
    location.href = "https://compsci326-f22-group2.herokuapp.com/settings.html";
});
$(".stats").click(function () {
    location.href = "https://compsci326-f22-group2.herokuapp.com/personalstats.html";
});
$(".account").click(function () {
    location.href = "https://compsci326-f22-group2.herokuapp.com/signuplogin.html";
});
