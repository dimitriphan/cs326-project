
         $(document).ready(function() {
         $('input[name=email]').keyup(function() {
           var $alert = $('#alert');
           var email = $(this).val();
         if (email.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)){ 
           $alert.text("Valid Email!");
         } else{
           $alert.text("Invalid Email!")
         }});});
         
         $(document).ready(function() {
         $('input[name=email1]').keyup(function() {
           var $alert1 = $('#alert1');
           var email1 = $(this).val();
         if (email1.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)){ 
          $alert1.text("Valid Email!");
         } else{
            $alert1.text("Invalid Email!");
         }});});
         
         $(document).ready(function() {
         $('input[name=password]').keyup(function() {
         var password = $(this).val();
         if (password.match(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{7,20}$/)){ 
         $('#require').removeClass('uncheck').addClass('check');
         }else { 
         $('#require').removeClass('check').addClass('uncheck');
         }})});
         
         function Empty() {
          if (document.getElementById("email1").value =="" || document.getElementById("password1").value =="") {
            alert("Enter Email and Password");
          } else if (
            !document.getElementById("email1").value.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/) 
            || !document.getElementById("password1").value.match(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{7,}$/)){
              alert("Enter Valid Email and Password");
            } else{
            location.href="https://compsci326-f22-group2.herokuapp.com/game";
          }
        }
        function IsEmpty() {
          if (document.getElementById("email").value =="" || document.getElementById("password").value =="") {
            alert("Enter Email and Password to Sign Up");
          } else if (
            !document.getElementById("email").value.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/) 
            || !document.getElementById("password").value.match(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{7,}$/)){
              alert("Enter Valid Email and Password");
            } else {
            location.href= 'https://compsci326-f22-group2.herokuapp.com/game';
          }
          }
 
         
         
        