

$.get('/pstats', compileStats );
function compileStats(data) {
    let highscores = [];
    let user3Scores = '';
    let user3Rank = 0;
    let user3Seen = false;
    let nonNullScores = 0;
    console.log(data);
    for (user of data.results){
        //for finding non null scores for highscore
        if (user.highscores !== null && !user3Seen) {
            nonNullScores++;
        }
        //finds the user, in this case it's user3@gmail.com and initializes its variables
        if (user.email==='user3@gmail.com') {
            user3Scores = user.scores;
            user3Rank = nonNullScores;
            user3Seen = true;
        }
        //code for the top 3 leaderboard
        if (user.highscores !== null && highscores.length <= 3) {
            highscores.push(`${user.email} : ${user.highscores}`);
        } 
        
    }
    //replaces the top 3 scores with the user and their score
    document.getElementById("score1").innerHTML = highscores[0];
    document.getElementById("score2").innerHTML = highscores[1];
    document.getElementById("score3").innerHTML = highscores[2];
       
    //inverses stats for graph so that it properly increases on higher score
    function inverseStats(stats) {
        const fixedStats = [];
            for(let i = 0; i < stats.length; i++) {
                num = stats[i] * -1;
                fixedStats.push(num);
            }
            return fixedStats;
        }
        let userTopScore = $("#stat1");
        let userRank = $("#stat2");
        
        
        userTopScore.html("Temporary Score 1");
        userRank.html("Temporary Score 2");
        
        let userName = $("#userName").html();
        //Gets username
        
        let canvas = document.getElementById("myCanvas");
        let context = canvas.getContext("2d");
        let scoreStat = user3Scores.split(',');
        let graphStat = [];
        
        //Gets the last 8 scores for the graph
        for (i = 0; i < scoreStat.length; i++) {
            num = scoreStat[scoreStat.length - i - 1];
            graphStat.push(num);
        }
        
        
        let userStats = inverseStats(graphStat);
        userStats = userStats.reverse();
        maxStat = ((Math.max.apply(Math, scoreStat)));
        userTopScore.html(maxStat);
        userRank.html(user3Rank);
        

        //Get 8 of user's previous scores
        //Graph Text
        
        // nick - changing color of this based on theme
        if (localStorage.getItem("theme") == "light") {
            context.fillStyle = "black";
            context.strokeStyle = "black";
        }
        else {
            context.fillStyle = "white";
            context.strokeStyle = "white";
        }
        
        //---------
        context.font = "15px Courier New";
        context.fillText(`${userName.trim()}'s Previous 8 Scores`, 20, 40);
        context.stroke();
        //Graph Line
        context.moveTo(10, 100);
        context.beginPath();
        context.lineWidth = 6;
        for (let i = 0; i < userStats.length ;i++ ) {
            context.lineTo( i*50+12, (userStats[i])*(7)+300);
        }
        context.font = "15px Courier New";
        context.fillText("Your recent highest was " + (Math.max.apply(Math, graphStat)) + " points ", 60, 60);
        context.stroke();
}

