function incrementScore(){
    let $score = $('#score').text();

    $score = parseInt($score);
    $score+=1;
    $('#score').html($score);
  }

  function checkHigher(){
    let $score = $('#score').text();
    let index1 = games.findIndex(game => game.name === $('.title1').text());
    let index2 = games.findIndex(game => game.name === $('.title2').text());


    if(games[index1].reviewcount <= games[index2].reviewcount){
      let newGameIndex = Math.floor(Math.random()*games.length);
      while(games[newGameIndex].name === games[index2].name){
          newGameIndex = Math.floor(Math.random()*games.length);
      }
      incrementScore();
      $('#img1').attr('src', $('#img2').attr('src'));
      $('#img2').attr('src', games[newGameIndex].pictureurl);
      updateInfo(games[index2], games[newGameIndex]);
    }else{
      alert("Nice try! You got " + $score + " correct! " + games[index2].name + " has " + games[index2].reviewcount.toLocaleString("en-US") + " reviews.");
      reset();
    }
  }

  function checkLower(){
    let $score = $('#score').text();
    let index1 = games.findIndex(game => game.name === $('.title1').text());
    let index2 = games.findIndex(game => game.name === $('.title2').text());
    if(games[index1].reviewcount >= games[index2].reviewcount){
      let newGameIndex = Math.floor(Math.random()*games.length);
      while(games[newGameIndex].name === games[index2].name){
          newGameIndex = Math.floor(Math.random()*games.length);
      }
      incrementScore();
      $('#img1').attr('src', $('#img2').attr('src'));
      $('#img2').attr('src', games[newGameIndex].pictureurl);
      updateInfo(games[index2], games[newGameIndex]);
    }else{
      alert("Nice try! You got " + $score + " correct! " + games[index2].name + " has " + games[index2].reviewcount.toLocaleString("en-US") + " reviews.");
      reset();
  }
}

  function updateInfo(g1, g2){
    $('.title1').html(g1.name);
    $('.title2').html(g2.name);
    $('.metric1').html(g1.reviewcount.toLocaleString("en-US") + ' reviews');
  }
  function reset(){
    let index1 = Math.floor(Math.random()*games.length);
    let index2 = Math.floor(Math.random()*games.length);
    while(index1===index2){
      index2 = Math.floor(Math.random()*games.length);
    }
    $('#score').html('0');
    $('#img1').attr('src', games[index1].pictureurl);
    $('#img2').attr('src', games[index2].pictureurl);
    $('.title1').html(games[index1].name);
    $('.title2').html(games[index2].name);
    $('.metric1').html(games[index1].reviewcount.toLocaleString("en-US") + ' reviews');
  }
  $("#higherButton").click(checkHigher);
  $("#lowerButton").click(checkLower);
  $(".settings").click(function () {
    location.href = "https://compsci326-f22-group2.herokuapp.com/settings.html";
  });
  $(".stats").click(function () {
    location.href = "https://compsci326-f22-group2.herokuapp.com/personalstats.html";
  });
  $(".account").click(function () {
    location.href = "https://compsci326-f22-group2.herokuapp.com/signuplogin.html";
  });