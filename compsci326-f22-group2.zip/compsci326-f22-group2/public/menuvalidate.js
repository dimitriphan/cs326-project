// menuvalidate.js
// Peter Klemperer
// January 3, 2021

let sidesValid = false;

// TODO add in validation to make sure that exactly three sides were selected

