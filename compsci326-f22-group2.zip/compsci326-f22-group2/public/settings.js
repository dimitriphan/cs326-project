


// not working for some reason

// $(".backButton").click(function () {
//     location.href = "https://compsci326-f22-group2.herokuapp.com/gamepage.html";
// });

// $(".acctButton").click(function () {
//     location.href = "https://compsci326-f22-group2.herokuapp.com/personalstats.html";
// });